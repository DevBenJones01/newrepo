#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>
#include <SDL_mixer.h>

#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

bool quit = false;

float deltaTime = 0.0;
int thisTime = 0;
int lastTime = 0;

//player movement - controled by keypress
int playerMovement = 71;

//create player rect
SDL_Rect playerPos;

//NEW PATROLLING 1 ******************************

#include "Enemy.h"
#include <vector>

vector<Enemy> enemyList;
int numberOfEnemies;

//NEW PATROLLING 1 ******************************

//NEW INVENTORY 1 ****************************************

#include "Coin.h"

//coin list vector
vector<Coin> coinList;

//max number of coins
int numberOfCoins;

//coin pickup sound
Mix_Chunk* pickup;

//NEW INVENTORY 1 ****************************************

int main(int argc, char* argv[]) {

	SDL_Window* window;

	SDL_Renderer* renderer = NULL;

	SDL_Init(SDL_INIT_EVERYTHING);

	window = SDL_CreateWindow(
		"Dungeon Crawler",
		SDL_WINDOWPOS_UNDEFINED,
		SDL_WINDOWPOS_UNDEFINED,
		642,
		358,
		SDL_WINDOW_OPENGL

	);

	if (window == NULL)
	{
		printf("Could not create window: %s\n", SDL_GetError());
		return 1;
	}

	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

	SDL_Surface* surface = IMG_Load("./Assets/level.png");

	SDL_Texture* bkgd;

	bkgd = SDL_CreateTextureFromSurface(renderer, surface);

	SDL_FreeSurface(surface);

	SDL_Rect bkgdPos;

	bkgdPos.x = 0;
	bkgdPos.y = 0;
	bkgdPos.w = 642;
	bkgdPos.h = 358;

	//player image creation
	//load new surface
	surface = IMG_Load("./Assets/player.png");

	// create player texture
	SDL_Texture* player;

	//place surface into texture
	player = SDL_CreateTextureFromSurface(renderer, surface);

	//free the surface
	SDL_FreeSurface(surface);

	//set player pos
	playerPos.x = 291;
	playerPos.y = 291;
	playerPos.w = 59;
	playerPos.h = 59;




	// player image create end

	SDL_Event event;

	const int mazeWidth = 9;
	const int mazeHeight = 5;

	//create the array for the maze "O" - open pace, "W" = wall, "P" = player
	string maze[mazeHeight][mazeWidth] =
	{
	 {"O","O","O","O","O","O","O","O","O"},
	 {"O","W","O","W","W","W","O","W","O"},
	 {"O","O","O","O","W","O","O","O","O"},
	 {"O","W","O","W","W","W","O","W","O"},
	 {"O","O","O","O","P","O","O","O","O"}
	};

	//player starting position in maze row 5 Column 5 - maze[4][4]5
	int playerHorizontal = 4;
	int playerVeritcal = 4;

	//NEW PATROLLING 2 ***************************

	//clear enemy list
	enemyList.clear();

	//fill enemy lsit

	//max num of enemies
	numberOfEnemies = 4;

	//enemy for the upper right area
	Enemy tempEnemy(renderer, 71, 2, 2, "left", "CCW", 575, 7);

	//Add enemy to lost
	enemyList.push_back(tempEnemy);

	//enemy for the upper left area
	Enemy tempEnemyD(renderer, 71, 2, 2, "right", "CW", 7, 7);

	//Add enemy to lost
	enemyList.push_back(tempEnemyD);

	//enemy for the lower right area
	Enemy tempEnemy3(renderer, 71, 2, 2, "right", "CW", 433, 149);

	//Add enemy to lost
	enemyList.push_back(tempEnemy3);

	//enemy for the lower left area
	Enemy tempEnemy4(renderer, 71, 2, 2, "up", "CCW", 149, 291);

	//Add enemy to lost
	enemyList.push_back(tempEnemy4);

	//NEW PATROLLING 2 ***************************

	//NEW INVENTORY 2 *****************************************

	//clear coin list
	coinList.clear();

	//fill coinlist

	//number of coins max
	numberOfCoins = 4;

	//coins player has picked up
	int totalCoins = 0;

	//add coin to the upper left screen
	Coin tempCoin(renderer, 18, 18);

	//add to the coin list
	coinList.push_back(tempCoin);

	//add coin to the upper left screen
	Coin tempCoin2(renderer, 18, 302);

	//add to the coin list
	coinList.push_back(tempCoin2);

	//add coin to the upper left screen
	Coin tempCoin3(renderer, 586, 18);

	//add to the coin list
	coinList.push_back(tempCoin3);

	//add coin to the upper left screen
	Coin tempCoin4(renderer, 586, 302);

	//add to the coin list
	coinList.push_back(tempCoin4);

	//initalize audio playeback
	Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048);

	pickup = Mix_LoadWAV("./Assets/pickup.wav");

	//NEW INVENTORY 2 *****************************************
	while (!quit)
	{
		//create deltaTime
		thisTime = SDL_GetTicks();
		deltaTime = (float)(thisTime - lastTime) / 1000;
		lastTime = thisTime;

		if (SDL_PollEvent(&event))
		{
			if (event.type == SDL_QUIT)
			{
				quit = true;
				break;
			}

			switch (event.type)
			{

			case SDL_KEYUP:
				switch (event.key.keysym.sym)
				{
				case SDLK_RIGHT: //Move right
					//boundarty check
					// the player will not go off the right of screen
					if ((playerHorizontal + 1) < mazeWidth)
					{
						if (maze[playerVeritcal][playerHorizontal + 1] == "O")
						{
							//Move the player spot to the new spot
							maze[playerVeritcal][playerHorizontal + 1] = "P";

							//Change the old spot to a O
							maze[playerVeritcal][playerHorizontal] = "O";

							//increase player horizontal 
							playerHorizontal += 1;

							//increase the player's position X by 71
							playerPos.x += playerMovement;
						}
						
					}
					break;
				case SDLK_LEFT: //move left
					//the player will not go off the left of screen
					if ((playerHorizontal - 1) >= 0)
					{
						if (maze[playerVeritcal][playerHorizontal - 1] == "O")
						{
							//Move the player spot to the new spot
							maze[playerVeritcal][playerHorizontal - 1] = "P";

							//Change the old spot to a O
							maze[playerVeritcal][playerHorizontal] = "O";

							//decrease player horizontal 
							playerHorizontal -= 1;

							//decrease the player position x by 71
							playerPos.x -= playerMovement;

						}

					}
					break;
				case SDLK_UP: //move up
					//the player will not go off the top of screen
					if ((playerVeritcal - 1) >= 0)
					{
						if (maze[playerVeritcal-1][playerHorizontal] == "O")
						{
							//Move the player spot to the new spot
							maze[playerVeritcal - 1][playerHorizontal] = "P";

							//Change the old spot to a O
							maze[playerVeritcal][playerHorizontal] = "O";

							//decrease player vertical 
							playerVeritcal -= 1;

							//decrease the player position y by 71
							playerPos.y -= playerMovement;
						}
						
					}
					break;
				case SDLK_DOWN: //move down
					//the player will not go off the bottom of screen
					if ((playerVeritcal + 1) < mazeHeight)
					{
						if (maze[playerVeritcal + 1][playerHorizontal] == "O")
						{
							//Move the player spot to the new spot
							maze[playerVeritcal + 1][playerHorizontal] = "P";

							//Change the old spot to a O
							maze[playerVeritcal][playerHorizontal] = "O";

							//increase player vertical 
							playerVeritcal += 1;

							//increase the player position y by 71
							playerPos.y += playerMovement;
						}

					
					}
					break;
				default:
					break;
				}

			}

		}

		//START UPDATE**************************
		for (int i = 0; i < numberOfEnemies; i++)
		{
			enemyList[i].Update(deltaTime);
		}

		for (int i = 0; i < enemyList.size(); i++)
		{
			if (SDL_HasIntersection(&playerPos, &enemyList[i].posRect))
			{
				cout << "You have lost!!!!" << endl;
			}
		}

		for (int i = 0; i < coinList.size(); i++)
		{
			if (SDL_HasIntersection(&playerPos, &coinList[i].posRect))
			{


				//remove coin
				coinList[i].RemoveFromScreen();

				//play pickup sound
				Mix_PlayChannel(-1, pickup, 0);

				//add coin to toal
				totalCoins++;

				//output some temp feedback
				cout << "Total coins found: " << totalCoins << endl;

				if (totalCoins == 4)
				{
					cout << "You have won!!!" << endl;
				}
			}


		}

		//END UPDATE**************************

		//START DRAW
		//Draw background
		//clear buffer
		SDL_RenderClear(renderer);

		//prepare to draw build
		SDL_RenderCopy(renderer, bkgd, NULL, &bkgdPos);

		//prepare to draw build
		SDL_RenderCopy(renderer, player, NULL, &playerPos);

		//draw enemies
		for (int i = 0; i < numberOfEnemies; i++)
		{
			enemyList[i].Draw(renderer);
		}

		//draw Coins

		for (int i = 0; i < numberOfCoins; i++)
		{
			coinList[i].Draw(renderer);
		}

		//draw new info to the screen
		SDL_RenderPresent(renderer);
		//END DRAW

	} //game loop end

	//end of game
	//close and destroy window
	SDL_DestroyWindow(window);

	//clean up
	SDL_Quit();

	return 0;
}