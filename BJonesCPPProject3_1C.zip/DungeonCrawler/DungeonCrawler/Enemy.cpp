#include "Enemy.h"

#include <string>

Enemy::Enemy(SDL_Renderer* renderer, int speed, int maxH, int maxV, string dir, string type, int startX, int startY)
{
	enemyMovement = speed; // set up in pixels

	maxHorizontalMovement = maxH; //max number of moves enemy can make from left to right 

    maxVerticalMovement = maxV; //max nu7mbert of moves enemy bcan make from top to bot

	currentDirection = dir; // the direct8ion the enemy is currently moving

	enemyType = type; //States if enemy is clockwise or counter clockwise

	SDL_Surface* surface = IMG_Load("./Assets/enemy.png");

	texture = SDL_CreateTextureFromSurface(renderer, surface);

	SDL_FreeSurface(surface);

	posRect.x = startX; //starting X for the enemy
	posRect.y = startY; //starting Y for the enemy

	int w, h;

	SDL_QueryTexture(texture, NULL, NULL, &w, &h);

	posRect.w = w;
	posRect.h = h;

	lastTime = 0; // int used to hold the lastest value of currentTime
}

void Enemy::Update(float deltaTime)
{
	//move once per half second 1000 = 1 sec
	//update currentTime to latest time
	currentTime = SDL_GetTicks();

	//check to see if half a secon has past, if so, move enemy
	if (currentTime > lastTime + 500)
	{
		if ((currentDirection == "left") && (horizontalCounter < maxHorizontalMovement)) //if the enemy want to move left and still has horizontal moves available
		{
			posRect.x -= enemyMovement; //move enemy 1 increment

			horizontalCounter++; // add to counter that enemy moved horizontally

			if (horizontalCounter >= maxHorizontalMovement)
			{
				horizontalCounter = 0; // reset horizontal movement to 0

				if (enemyType == "CW") //Clockwise
				{
					currentDirection = "up";
				}
				else if (enemyType == "CCW") //COunter clockwise
				{
					currentDirection = "down";
				}
			}
		}
		else if ((currentDirection == "down") && (verticalCounter < maxVerticalMovement)) //if the enemy want to move down and still has vertical moves available
		{
			posRect.y += enemyMovement; //move enemy 1 increment

			verticalCounter++; // add to counter that enemy moved vertically

			if (verticalCounter >= maxVerticalMovement)
			{
				verticalCounter = 0; // reset horizontal movement to 0

				if (enemyType == "CW") //Clockwise
				{
					currentDirection = "left";
				}
				else if (enemyType == "CCW") //COunter clockwise
				{
					currentDirection = "right";
				}
			}
		}
		else if ((currentDirection == "right") && (horizontalCounter < maxVerticalMovement)) //if the enemy want to move right and still has horizontal moves available
		{
			posRect.x += enemyMovement; //move enemy 1 increment

			horizontalCounter++; // add to counter that enemy moved horizontally

			if (horizontalCounter >= maxHorizontalMovement)
			{
				horizontalCounter = 0; // reset horizontal movement to 0

				if (enemyType == "CW") //Clockwise
				{
					currentDirection = "down";
				}
				else if (enemyType == "CCW") //COunter clockwise
				{
					currentDirection = "up";
				}
			}
		}
		else if ((currentDirection == "up") && (verticalCounter < maxVerticalMovement)) //if the enemy want to move up and still has vertical moves available
		{
			posRect.y -= enemyMovement; //move enemy 1 increment

			verticalCounter++; // add to counter that enemy moved vertically

			if (verticalCounter >= maxVerticalMovement)
			{
				verticalCounter = 0; // reset horizontal movement to 0

				if (enemyType == "CW") //Clockwise
				{
					currentDirection = "right";
				}
				else if (enemyType == "CCW") //COunter clockwise
				{
					currentDirection = "left";
				}
			}
		}


		lastTime = currentTime; //update clock
	}
}

void Enemy::Draw(SDL_Renderer* renderer)
{
	SDL_RenderCopy(renderer, texture, NULL, &posRect);
}

Enemy::~Enemy()
{
	//SDL_DestroyTexture(texture);
}


