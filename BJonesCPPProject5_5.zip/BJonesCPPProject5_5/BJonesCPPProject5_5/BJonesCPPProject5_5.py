import sqlite3 as s1

#Create connection
con = s1.connect('movies.db')

#Once Connected, create cursor object to exectute SQL statements
C = con.cursor()

#get the count of tables with the name to see if it exist
C.execute(''' SELECT count(name) FROM sqlite_master WHERE type='table' AND name='USER' ''')

if C.fetchone()[0]==1:
    #if it exist

    print('Table Exist')

else :
    #if not
    print('Table does not exist')

    # create a table with a primary key, movie name, Genre, and release date
    with con:
        con.execute("""
            CREATE TABLE USER (
                id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                MovieName TEXT,
                Genre TEXT,
                ReleaseDate DATE
             );
        """)

        sql = 'INSERT INTO USER (id, MovieName, Genre, ReleaseDate) values(?,?,?,?)'
        data = [
            (1, 'Avengers Endgame', 'Action', '2019-04-26'),
            (2, 'Avengers Infinity war', 'Action', '2018-04-23'),
            (3, 'Silverado', 'Western', '1985-07-10'),
            (4, 'Goldeneye', 'Spy', '1995-11-13'),
            (5, 'Eragon', 'Fantasy', '2006-12-15'),
            (6, 'Iron Man', 'Action', '2008-05-02'),
            (7, 'Captain America: First Avenger', 'Super Hero', '2011-07-19'),
            (8, 'Jurassic Park', 'Action', '1993-06-11'),
            (9, 'Forrest Gump', 'Romance', '1994-07-06'),
            (10,'Star Wars', 'Action', '1977-04-26'),       
            ]

    with con:
        con.executemany(sql, data)

print('Where the release date is equal to or greater than 2000')
with con:
    data = con.execute("SELECT * FROM USER WHERE ReleaseDate >= '2000-01-01'")
    for row in data:
        print(row)

print('Where the release date is less than 2000')
with con:
    data = con.execute("SELECT * FROM USER WHERE ReleaseDate < '2000-01-01'")
    for row in data:
        print(row)